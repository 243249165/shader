(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/AnimationEx.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2ca4didCihAGYI1BLT0mmCs', 'AnimationEx', __filename);
// AnimationEx.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property, executionOrder = _a.executionOrder;
/** 播放模式类型 */
var WrapModeEx;
(function (WrapModeEx) {
    WrapModeEx[WrapModeEx["Default"] = 0] = "Default";
    WrapModeEx[WrapModeEx["Loop"] = 1] = "Loop";
})(WrapModeEx = exports.WrapModeEx || (exports.WrapModeEx = {}));
/** 动画变化值类型 */
var PlayAnimChangeType;
(function (PlayAnimChangeType) {
    PlayAnimChangeType[PlayAnimChangeType["spriteFrame"] = 0] = "spriteFrame";
    PlayAnimChangeType[PlayAnimChangeType["opacity"] = 1] = "opacity"; // 透明度每帧变化
})(PlayAnimChangeType || (PlayAnimChangeType = {}));
/**
 * 自定义中心点对齐的动画
 * @author wxl
 */
var AnimationEx = /** @class */ (function (_super) {
    __extends(AnimationEx, _super);
    function AnimationEx() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /** 切片图集 */
        _this.atlas = null;
        /** 首帧索引 */
        _this.frameIndex = 0;
        /** 动画的帧速率 */
        _this.clipSample = 60;
        /** 动画帧数，如果没设置则取图集的总帧数 */
        _this.framesCount = 0;
        /** 动画使用的循环模式 */
        _this.wrapMode = WrapModeEx.Loop;
        /** 动画开始播放速度 */
        _this.speed = 0.05;
        /** 动画变化类型 */
        _this.playChangeType = PlayAnimChangeType.spriteFrame;
        /** 最大透明度 */
        _this.maxOpacity = 255;
        /** 最小透明度 */
        _this.minOpacity = 195;
        /** 每秒变化速度 */
        _this.durOpacity = 255;
        _this._playFun = function (dt) { return void []; };
        /** 计数器 */
        _this._speedCountTimes = 0;
        /** 变化速度 */
        _this._changeOpacity = 0;
        /** 是否停止 */
        _this._isStop = false;
        /** 播放完成回调 */
        _this._callBack = null;
        /** 节点精灵 */
        _this._nodeSprite = null;
        _this._spriteFrameChangeListener = null;
        return _this;
    }
    AnimationEx.prototype.onLoad = function () {
        this.initPlayAnim();
        this._changeOpacity = -this.durOpacity;
        this._nodeSprite = this.node.getComponent(cc.Sprite);
        if (!this._nodeSprite) {
            cc.log("sprite component is null");
        }
        if (!this.atlas) {
            return;
        }
        if (this.framesCount == 0) {
            this.framesCount = this.atlas.getSpriteFrames().length;
        }
        this.setFrameIndex(this.frameIndex, true);
    };
    AnimationEx.prototype.update = function (dt) {
        if (this._playFun[this.playChangeType]) {
            this._playFun[this.playChangeType].call(this, dt);
        }
    };
    /** 初始化函数数组 */
    AnimationEx.prototype.initPlayAnim = function () {
        this._playFun = function (dt) { return void []; };
        this._playFun[PlayAnimChangeType.spriteFrame] = this.playAnimBySpriteFrame;
        this._playFun[PlayAnimChangeType.opacity] = this.playAnimByOpacity;
    };
    /** 设置当前帧 */
    AnimationEx.prototype.setFrameIndex = function (index, isReset) {
        if (isReset === void 0) { isReset = true; }
        if (!this.atlas) {
            return;
        }
        if (isReset) {
            this.framesCount = this.atlas.getSpriteFrames().length;
        }
        if (this.frameIndex < 0 || this.frameIndex > this.framesCount - 1) {
            return;
        }
        if (!this._nodeSprite) {
            // cc.error("sprite component is null");
            return;
        }
        var oldFrameIndex = this.frameIndex;
        this.frameIndex = index;
        this._nodeSprite.spriteFrame = this.atlas.getSpriteFrames()[this.frameIndex];
        if (this._spriteFrameChangeListener && oldFrameIndex !== this.frameIndex) {
            this._spriteFrameChangeListener(this.frameIndex);
        }
    };
    /** 动作重置 */
    AnimationEx.prototype.reset = function () {
        this._isStop = false;
        this.setFrameIndex(0);
    };
    /**
     * 播放
     * @param callBack 播放完成回调
     */
    AnimationEx.prototype.playOnce = function (callBack) {
        if (!this._nodeSprite) {
            return;
        }
        this._isStop = false;
        this.setFrameIndex(0);
        this._callBack = callBack;
    };
    /** 暂停动画 */
    AnimationEx.prototype.pause = function () {
        this._isStop = true;
    };
    /** 重新播放动画 */
    AnimationEx.prototype.resume = function () {
        this._isStop = false;
    };
    AnimationEx.prototype.setSpriteFrameChangeListener = function (listener) {
        this._spriteFrameChangeListener = listener;
    };
    /** 精灵每帧变化 */
    AnimationEx.prototype.playAnimBySpriteFrame = function (dt) {
        if (!this.atlas || this._isStop) {
            return;
        }
        this._speedCountTimes += dt;
        if (this._speedCountTimes >= this.speed) {
            this._speedCountTimes = 0;
            var index = this.frameIndex + 1;
            if (this.frameIndex >= this.framesCount - 1) {
                this.setFrameIndex(0, false);
                this._speedCountTimes = 0;
                this.doStop();
            }
            else {
                this.setFrameIndex(index, false);
            }
        }
    };
    /** 透明度每帧变化 */
    AnimationEx.prototype.playAnimByOpacity = function (dt, callBack) {
        if (this._isStop) {
            return;
        }
        if (this.node.opacity >= this.maxOpacity) {
            this._changeOpacity = -this.durOpacity;
            this.doStop();
        }
        if (this.node.opacity <= this.minOpacity) {
            this._changeOpacity = this.durOpacity;
        }
        this.node.opacity += this._changeOpacity * dt;
        this.node.opacity = this.node.opacity > this.maxOpacity ? this.maxOpacity : this.node.opacity;
        this.node.opacity = this.node.opacity < this.minOpacity ? this.minOpacity : this.node.opacity;
    };
    /** 播放完成回调处理 */
    AnimationEx.prototype.doStop = function () {
        if (this.wrapMode === WrapModeEx.Default) {
            this._isStop = true;
            if (this._callBack && this.node && this.node.isValid) {
                this._callBack(this.node);
            }
            return true;
        }
        return false;
    };
    AnimationEx.prototype.onEnable = function () {
        if (this.playChangeType === PlayAnimChangeType.opacity) {
            this.node.opacity = this.minOpacity;
        }
        this._isStop = false;
    };
    AnimationEx.prototype.onDisable = function () {
        if (this.playChangeType === PlayAnimChangeType.opacity) {
            this.node.opacity = this.minOpacity;
        }
        this.frameIndex = 0;
        this._isStop = true;
    };
    AnimationEx.prototype.getAnimTotalTime = function () {
        return this.speed * this.framesCount;
    };
    __decorate([
        property({ type: cc.SpriteAtlas, tooltip: "切片图集" })
    ], AnimationEx.prototype, "atlas", void 0);
    __decorate([
        property({ type: cc.Integer, tooltip: "首帧索引" })
    ], AnimationEx.prototype, "frameIndex", void 0);
    __decorate([
        property({ type: cc.Integer, tooltip: "动画的帧速率" })
    ], AnimationEx.prototype, "clipSample", void 0);
    __decorate([
        property({ type: cc.Integer, tooltip: "动画帧数，如果没设置则取图集的总帧数" })
    ], AnimationEx.prototype, "framesCount", void 0);
    __decorate([
        property({ type: cc.Integer, tooltip: "动画使用的循环模式,0为播放一次模式，1为循环播放模式" })
    ], AnimationEx.prototype, "wrapMode", void 0);
    __decorate([
        property({ type: cc.Float, tooltip: "动画开始播放速度" })
    ], AnimationEx.prototype, "speed", void 0);
    __decorate([
        property({ type: cc.Integer, tooltip: "动画变化类型，0为精灵每帧变化，1为透明度每帧变化" })
    ], AnimationEx.prototype, "playChangeType", void 0);
    __decorate([
        property({ type: cc.Float, tooltip: "最大透明度" })
    ], AnimationEx.prototype, "maxOpacity", void 0);
    __decorate([
        property({ type: cc.Float, tooltip: "最小透明度" })
    ], AnimationEx.prototype, "minOpacity", void 0);
    __decorate([
        property({ type: cc.Float, tooltip: "每秒变化速度" })
    ], AnimationEx.prototype, "durOpacity", void 0);
    AnimationEx = __decorate([
        ccclass
    ], AnimationEx);
    return AnimationEx;
}(cc.Component));
exports.AnimationEx = AnimationEx;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=AnimationEx.js.map
        