(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/role/phantom.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'd29f7MbP9lO87dgH03+b85K', 'phantom', __filename);
// role/phantom.ts

Object.defineProperty(exports, "__esModule", { value: true });
var AnimationEx_1 = require("../AnimationEx");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var phantom = /** @class */ (function (_super) {
    __extends(phantom, _super);
    function phantom() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**  摄像机 */
        _this.camera = null;
        /** 精灵节点 */
        _this.spriteNode = null;
        /**  幻影数量 */
        _this.spriteCount = 5;
        /**  幻影数量 */
        _this.spriteTime = 0.05;
        /** 错帧播放 */
        _this.isStagge = false;
        _this._spriteNode = null; //保存初始节点信息
        _this._sprShadows = []; // 保存摄像机画布数组
        _this._spriteMove = new cc.Node; // 精灵移动数据存储节点
        return _this;
    }
    phantom.prototype.onLoad = function () {
        this._spriteNode = this.spriteNode;
    };
    phantom.prototype.onDestroy = function () {
        this.unscheduleAllCallbacks();
    };
    /** 初始化幻影节点需要的内容 */
    phantom.prototype.initSprite = function () {
        this._sprShadows = [];
        /** 实例化影子节点 */
        for (var i = 0; i < this.spriteCount; i++) {
            /** 设置影子属性 */
            var node = null;
            if (this.node.children[i].name == "shadow" + i) {
                node = this.node.children[i];
            }
            else {
                node = cc.instantiate(this.spriteNode);
            }
            node.active = true;
            node.name = "shadow" + i;
            node.parent = this.node;
            node.setPosition(0, 0);
            node.setSiblingIndex(i);
            node.opacity = 40 + i * 40;
            node.scaleX = this._spriteNode.scaleX;
            node.scaleY = this._spriteNode.scaleY;
            /** 错帧播放 动作不同步 */
            if (this.isStagge) {
                var animationEx = node.getComponent(AnimationEx_1.AnimationEx);
                if (animationEx && animationEx.atlas) {
                    var sprites = animationEx.atlas.getSpriteFrames();
                    var a = i * 2 > sprites.length - 1 ? sprites.length - 1 : i * 2;
                    animationEx.setFrameIndex(a);
                }
            }
            /** 保存摄像机画布数组 */
            this._sprShadows.push(node);
        }
        /** 把精灵主体层级设置到最上层 */
        this.spriteNode.setPosition(0, 0);
        this.spriteNode.setSiblingIndex(this.spriteCount);
        // this.bindCamera();
        this.schedule(this.shadowFollow, 0.1, cc.macro.REPEAT_FOREVER);
    };
    // /** 绑定摄像机 */
    // private bindCamera() {
    //     /** 绑定camera的targetTexture到显示画布spriteFrame */
    //     // const texture = new cc.RenderTexture();
    //     // texture.initWithSize(this.spriteNode.width, this.spriteNode.height);
    //     // const spriteFrame = new cc.SpriteFrame();
    //     // spriteFrame.setTexture(texture);
    //     // this.camera.targetTexture = texture;
    //     /** 设置幻影画布精灵 */
    //     this._sprShadows.forEach((v) => {
    //         v.getComponent(cc.Sprite).spriteFrame = this.spriteNode.getComponent(cc.Sprite).spriteFrame;
    //     });
    // }
    /** 影子跟随移动 */
    phantom.prototype.shadowFollow = function () {
        var _this = this;
        this._sprShadows.forEach(function (v, i) {
            var dis = _this.spriteNode.position.sub(v.position).mag();
            v.stopAllActions();
            if (dis > 10) {
                v.opacity = 40 + i * 40;
                v.scaleX = _this.spriteNode.scaleX;
                v.scaleY = _this.spriteNode.scaleY;
                var action1 = cc.moveTo((_this._sprShadows.length - i) * _this.spriteTime + 0.02, _this.spriteNode.x, _this.spriteNode.y);
                v.runAction(action1);
            }
            else {
                v.runAction(cc.fadeOut((_this._sprShadows.length - i) * _this.spriteTime / 2 + 0.02));
            }
        });
    };
    __decorate([
        property(cc.Camera)
    ], phantom.prototype, "camera", void 0);
    __decorate([
        property(cc.Node)
    ], phantom.prototype, "spriteNode", void 0);
    __decorate([
        property(Number)
    ], phantom.prototype, "spriteCount", void 0);
    __decorate([
        property(Number)
    ], phantom.prototype, "spriteTime", void 0);
    __decorate([
        property(Boolean)
    ], phantom.prototype, "isStagge", void 0);
    phantom = __decorate([
        ccclass
    ], phantom);
    return phantom;
}(cc.Component));
exports.default = phantom;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=phantom.js.map
        