(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/text.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a7ae3aYn2JOtJzaB/BArIaO', 'text', __filename);
// text.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ShaderComponent_1 = require("./shader/ShaderComponent");
var ShaderManager_1 = require("./shader/ShaderManager");
var phantom_1 = require("./role/phantom");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var text = /** @class */ (function (_super) {
    __extends(text, _super);
    function text() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /** 精灵节点 */
        _this.spriteNode = null;
        _this.imageNode = null;
        _this.timeCount = 0;
        return _this;
    }
    // onBtnCreat() {
    //     let node = new cc.Node();
    //     let sprite = node.addComponent(cc.Sprite);
    //     node.parent = this.node;
    //     node.name = 'image';
    //     cc.loader.load({ uuid: 'a62ac7a1-dbec-49e5-92cb-a09c84027f96' }, (err, spriteFrame) => {
    //         sprite.spriteFrame = spriteFrame;
    //         this.imageNode = sprite.node;
    //     });
    // }
    text.prototype.onBtnSet = function () {
        this.imageNode = this.node.getChildByName("roomMin");
        var shaderHelper = this.imageNode.getComponent(ShaderComponent_1.default);
        if (!shaderHelper) {
            shaderHelper = this.imageNode.addComponent(ShaderComponent_1.default);
        }
        if (this.timeCount >= 21) {
            this.timeCount = 0;
        }
        else {
            this.timeCount++;
        }
        shaderHelper.shader = this.timeCount;
        console.log(this.timeCount);
        this.node.getChildByName("roomMin").getChildByName("text").getComponent(cc.Label).string = ShaderManager_1.default.shaderName;
    };
    text.prototype.onBtnGo = function () {
        this.spriteNode.stopAllActions();
        this.spriteNode.setPosition(0, 0);
        this.spriteNode.parent.getComponent(phantom_1.default).initSprite();
        this.spriteNode.runAction(cc.moveTo(5, 500, 0));
        // this.spriteNode.runAction(cc.repeatForever(cc.sequence(cc.moveTo(5, 1000, 0), cc.callFunc(() => {
        //     this.spriteNode.scaleX = -0.5;
        //     this.spriteNode.scaleY = 0.5;
        // }), cc.moveTo(5, 0, 0), cc.callFunc(() => {
        //     this.spriteNode.scaleX = 0.5;
        //     this.spriteNode.scaleY = 0.5;
        // }))));
    };
    __decorate([
        property(cc.Node)
    ], text.prototype, "spriteNode", void 0);
    text = __decorate([
        ccclass
    ], text);
    return text;
}(cc.Component));
exports.default = text;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=text.js.map
        