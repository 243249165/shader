(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/shader/ShaderManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'd1e19w9UihLPqSppbSLUBq8', 'ShaderManager', __filename);
// shader/ShaderManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ShaderLab_1 = require("./ShaderLab");
var ShaderMaterial_1 = require("./ShaderMaterial");
var ShaderType;
(function (ShaderType) {
    ShaderType[ShaderType["Default"] = 0] = "Default";
    ShaderType[ShaderType["Gray"] = 1] = "Gray";
    ShaderType[ShaderType["GrayScaling"] = 2] = "GrayScaling";
    ShaderType[ShaderType["Stone"] = 3] = "Stone";
    ShaderType[ShaderType["Ice"] = 4] = "Ice";
    ShaderType[ShaderType["Frozen"] = 5] = "Frozen";
    ShaderType[ShaderType["Mirror"] = 6] = "Mirror";
    ShaderType[ShaderType["Poison"] = 7] = "Poison";
    ShaderType[ShaderType["Banish"] = 8] = "Banish";
    ShaderType[ShaderType["Vanish"] = 9] = "Vanish";
    // Invisible,//无形
    ShaderType[ShaderType["Blur"] = 10] = "Blur";
    ShaderType[ShaderType["GaussBlur"] = 11] = "GaussBlur";
    ShaderType[ShaderType["Dissolve"] = 12] = "Dissolve";
    ShaderType[ShaderType["Fluxay"] = 13] = "Fluxay";
    ShaderType[ShaderType["FluxaySuper"] = 14] = "FluxaySuper";
    ShaderType[ShaderType["Transfer"] = 15] = "Transfer";
    ShaderType[ShaderType["UnfoldTransfer"] = 16] = "UnfoldTransfer";
    ShaderType[ShaderType["ZoomBlurTransfer"] = 17] = "ZoomBlurTransfer";
    ShaderType[ShaderType["WindowTransfer"] = 18] = "WindowTransfer";
    ShaderType[ShaderType["overlay"] = 19] = "overlay";
    ShaderType[ShaderType["DynamicBlurTransfer"] = 20] = "DynamicBlurTransfer";
})(ShaderType = exports.ShaderType || (exports.ShaderType = {}));
/**
 * @author wxl
 * 材质管理器
 */
var ShaderManager = /** @class */ (function () {
    function ShaderManager() {
    }
    /**
     *
     * @param sprite 精灵
     * @param shader shader类型
     */
    ShaderManager.useShader = function (sprite, shader) {
        /** 着色器不支持画布 */
        if (cc.game.renderType === cc.game.RENDER_TYPE_CANVAS) {
            console.warn('Shader not surpport for canvas');
            return;
        }
        /** 设灰与精灵不存在 */
        if (!sprite || !sprite.spriteFrame || sprite.getState() === shader) {
            return;
        }
        if (shader > ShaderType.Gray) {
            /**  获取自定义shader*/
            var name = ShaderType[shader];
            var lab = ShaderLab_1.default[name];
            this.shaderName = name;
            /** shader不存在 */
            if (!lab) {
                console.warn('Shader not defined', name);
                return;
            }
            cc.dynamicAtlasManager.enabled = false;
            /** 获取当前shader相应的材质且设置参数 */
            var material = new ShaderMaterial_1.default(name, lab.vert, lab.frag, lab.defines || []);
            var texture = sprite.spriteFrame.getTexture();
            material.setTexture(texture);
            material.updateHash();
            // 切换到当前材质
            var sp = sprite;
            sp._material = material;
            sp._renderData._material = material;
            sp._state = shader;
            return material;
        }
        else {
            sprite.setState(shader);
        }
    };
    ShaderManager.shaderName = null;
    return ShaderManager;
}());
exports.default = ShaderManager;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=ShaderManager.js.map
        