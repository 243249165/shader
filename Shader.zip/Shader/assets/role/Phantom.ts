
const { ccclass, property } = cc._decorator;
/**
 * 自定义残影动画
 * @author wxl
 * 使用该脚本有层级规定，需要一个空父节点，精灵子节点，该脚本绑定在父节点上
 */
@ccclass
export default class Phantom extends cc.Component {


    /** 精灵节点 */
    @property(cc.Node)
    private spriteNode: cc.Node = null;
    /**  幻影数量 */
    @property(Number)
    private spriteCount: number = 5;
    /**  幻影数量 */
    @property(Number)
    private spriteTime: number = 0.05;
    /** 错帧播放 */
    @property(Boolean)
    private isStagge: boolean = false;

    private _spriteNode: cc.Node = null;//保存初始节点信息
    private _sprShadows: cc.Node[] = [];// 保存摄像机画布数组

    onLoad() {
        this._spriteNode = this.spriteNode;

    }

    onDestroy() {
        this.unscheduleAllCallbacks();
    }

    /** 初始化幻影节点需要的内容 */
    public initSprite() {
        this._sprShadows = [];
        /** 实例化影子节点 */
        for (let i = 0; i < this.spriteCount; i++) {
            /** 设置影子属性 */
            let node: cc.Node = null;
            if (this.node.children[i].name == "shadow" + i) {
                node = this.node.children[i];
            } else {
                node = cc.instantiate(this.spriteNode);
            }
            node.active = true;
            node.name = "shadow" + i;
            node.parent = this.node;
            node.setPosition(0, 0);
            node.setSiblingIndex(i);
            node.opacity = 40 + i * 40;
            node.scaleX = this._spriteNode.scaleX;
            node.scaleY = this._spriteNode.scaleY;
            /** 错帧播放 动作不同步 */
            if (this.isStagge) {
                let animationEx = node.getComponent(AnimationEx);
                if (animationEx && animationEx.atlas) {
                    let sprites = animationEx.atlas.getSpriteFrames();
                    let a = i * 2 > sprites.length - 1 ? sprites.length - 1 : i * 2;
                    animationEx.setFrameIndex(a);
                }
            }
            /** 保存摄像机画布数组 */
            this._sprShadows.push(node);
        }
        /** 把精灵主体层级设置到最上层 */
        this.spriteNode.setPosition(0, 0);
        this.spriteNode.setSiblingIndex(this.spriteCount);

        this.schedule(this.shadowFollow, 0.1, cc.macro.REPEAT_FOREVER);
    }



    /** 影子跟随移动 */
    private shadowFollow() {
        this._sprShadows.forEach((v, i) => {
            const dis = this.spriteNode.position.sub(v.position).mag();
            v.stopAllActions();
            if (dis > 10) {
                v.opacity = 40 + i * 40;
                v.scaleX = this.spriteNode.scaleX;
                v.scaleY = this.spriteNode.scaleY;
                let action1 = cc.moveTo((this._sprShadows.length - i) * this.spriteTime + 0.02, this.spriteNode.x, this.spriteNode.y);
                v.runAction(action1);
            } else {
                v.runAction(cc.fadeOut((this._sprShadows.length - i) * this.spriteTime / 2 + 0.02));
            }
        });
    }


}
