import { NodeEx } from "../../../games/catchfish/commonby/common/NodeEx";

const { ccclass, property, executionOrder } = cc._decorator;
type PlayAnimTypeFun = (dt: number) => void;

/** 播放模式类型 */
export enum WrapModeEx {
    Default = 0,// 播放一次模式
    Loop = 1,// 循环播放模式
}

/** 动画变化值类型 */
enum PlayAnimChangeType {
    spriteFrame = 0,// 精灵每帧变化
    opacity = 1// 透明度每帧变化
}

/**
 * 自定义中心点对齐的动画
 * @author wxl
 */
@ccclass
export class AnimationEx extends cc.Component {

    /** 切片图集 */
    @property({ type: cc.SpriteAtlas, tooltip: "切片图集" })
    public atlas: cc.SpriteAtlas = null;

    /** 首帧索引 */
    @property({ type: cc.Integer, tooltip: "首帧索引" })
    public frameIndex: number = 0;

    /** 动画的帧速率 */
    @property({ type: cc.Integer, tooltip: "动画的帧速率" })
    public clipSample: number = 60;

    /** 动画帧数，如果没设置则取图集的总帧数 */
    @property({ type: cc.Integer, tooltip: "动画帧数，如果没设置则取图集的总帧数" })
    public framesCount: number = 0;

    /** 动画使用的循环模式 */
    @property({ type: cc.Integer, tooltip: "动画使用的循环模式,0为播放一次模式，1为循环播放模式" })
    public wrapMode = WrapModeEx.Loop;

    /** 动画开始播放速度 */
    @property({ type: cc.Float, tooltip: "动画开始播放速度" })
    public speed: number = 0.05;

    /** 动画变化类型 */
    @property({ type: cc.Integer, tooltip: "动画变化类型，0为精灵每帧变化，1为透明度每帧变化" })
    public playChangeType: PlayAnimChangeType = PlayAnimChangeType.spriteFrame;

    /** 最大透明度 */
    @property({ type: cc.Float, tooltip: "最大透明度" })
    public maxOpacity: number = 255;

    /** 最小透明度 */
    @property({ type: cc.Float, tooltip: "最小透明度" })
    public minOpacity: number = 195;

    /** 每秒变化速度 */
    @property({ type: cc.Float, tooltip: "每秒变化速度" })
    public durOpacity: number = 255;
    private _playFun: (dt: Number) => void[] = (dt: Number) => void [];

    /** 计数器 */
    private _speedCountTimes: number = 0;

    /** 变化速度 */
    private _changeOpacity: number = 0;

    /** 是否停止 */
    private _isStop: boolean = false;

    /** 播放完成回调 */
    private _callBack: Function = null;

    /** 节点精灵 */
    private _nodeSprite: cc.Sprite = null;

    public onLoad() {
        this.initPlayAnim();
        this._changeOpacity = -this.durOpacity;
        this._nodeSprite = this.node.getComponent(cc.Sprite);
        if (!this._nodeSprite) {
            cc.log("sprite component is null");
        }

        if (!this.atlas) {
            return;
        }
        if (this.framesCount == 0) {
            this.framesCount = this.atlas.getSpriteFrames().length;
        }

        this.setFrameIndex(this.frameIndex, true);
    }

    public update(dt) {
        if (this._playFun[this.playChangeType]) {
            this._playFun[this.playChangeType].call(this, dt);
        }
    }


    /** 初始化函数数组 */
    private initPlayAnim() {
        this._playFun = (dt: Number) => void [];
        this._playFun[PlayAnimChangeType.spriteFrame] = this.playAnimBySpriteFrame;
        this._playFun[PlayAnimChangeType.opacity] = this.playAnimByOpacity;
    }


    /** 设置当前帧 */
    public setFrameIndex(index: number, isReset: boolean = true) {

        if (!this.atlas) {
            return;
        }

        if (isReset) {
            this.framesCount = this.atlas.getSpriteFrames().length;
        }

        if (this.frameIndex < 0 || this.frameIndex > this.framesCount - 1) {
            return;
        }
        if (!this._nodeSprite) {
            // cc.error("sprite component is null");
            return;
        }

        let oldFrameIndex = this.frameIndex;
        this.frameIndex = index;
        this._nodeSprite.spriteFrame = this.atlas.getSpriteFrames()[this.frameIndex];

        if (this._spriteFrameChangeListener && oldFrameIndex !== this.frameIndex) {
            this._spriteFrameChangeListener(this.frameIndex);
        }
    }

    /** 动作重置 */
    public reset() {
        this._isStop = false;
        this.setFrameIndex(0);
    }

    /**
     * 播放
     * @param callBack 播放完成回调
     */
    public playOnce(callBack?: Function) {
        if (!this._nodeSprite) {
            return;
        }

        this._isStop = false;
        this.setFrameIndex(0);
        this._callBack = callBack;
    }

    /** 暂停动画 */
    public pause() {
        this._isStop = true;
    }

    /** 重新播放动画 */
    public resume() {
        this._isStop = false;
    }

    private _spriteFrameChangeListener: (frameIndex: number) => void = null;
    public setSpriteFrameChangeListener(listener: (frameIndex: number) => void) {
        this._spriteFrameChangeListener = listener;
    }

    /** 精灵每帧变化 */
    private playAnimBySpriteFrame(dt) {
        if (!this.atlas || this._isStop) { return; }
        this._speedCountTimes += dt;

        if (this._speedCountTimes >= this.speed) {
            this._speedCountTimes = 0;
            let index = this.frameIndex + 1;

            if (this.frameIndex >= this.framesCount - 1) {
                this.setFrameIndex(0, false);
                this._speedCountTimes = 0;
                this.doStop();
            } else {
                this.setFrameIndex(index, false);
            }
        }
    }

    /** 透明度每帧变化 */
    private playAnimByOpacity(dt, callBack: Function) {
        if (this._isStop) { return; }
        if (this.node.opacity >= this.maxOpacity) {
            this._changeOpacity = -this.durOpacity;
            this.doStop();
        }
        if (this.node.opacity <= this.minOpacity) {
            this._changeOpacity = this.durOpacity;
        }
        this.node.opacity += this._changeOpacity * dt;
        this.node.opacity = this.node.opacity > this.maxOpacity ? this.maxOpacity : this.node.opacity;
        this.node.opacity = this.node.opacity < this.minOpacity ? this.minOpacity : this.node.opacity;

    }


    /** 播放完成回调处理 */
    private doStop(): boolean {
        if (this.wrapMode === WrapModeEx.Default) {
            this._isStop = true;
            if (this._callBack && this.node && this.node.isValid) {
                this._callBack(this.node);
            }
            return true;
        }
        return false;
    }

    public onEnable() {
        if (this.playChangeType === PlayAnimChangeType.opacity) {
            this.node.opacity = this.minOpacity;
        }
        this._isStop = false;
    }

    public onDisable() {
        if (this.playChangeType === PlayAnimChangeType.opacity) {
            this.node.opacity = this.minOpacity;
        }
        this.frameIndex = 0;
        this._isStop = true;
    }

    public getAnimTotalTime(): number {
        return this.speed * this.framesCount;
    }

}