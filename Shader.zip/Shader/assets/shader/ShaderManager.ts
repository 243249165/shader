import ShaderLab from "./ShaderLab";
import ShaderMaterial from "./ShaderMaterial";
import ShaderComponent from "./ShaderComponent";

export enum ShaderType {
    Default = 0, //默认
    Gray, //图片变灰
    GrayScaling,//图片变灰且加黑
    Stone, // 石化效果
    Ice, //冰冻效果（亮）
    Frozen,//结冰
    Mirror,//紫色
    Poison,//黄色
    Banish,//暗黑风
    Vanish,//黑色
    // Invisible,//无形
    Blur,//模糊
    GaussBlur,//模糊2.0
    Dissolve,//溶解
    Fluxay,//扫光
    FluxaySuper,//水波
    Transfer,//左右到后 消失
    UnfoldTransfer,//切割分离
    ZoomBlurTransfer,//对角线出现
    WindowTransfer,//上下消失出现离场效果
    overlay,//高光
    DynamicBlurTransfer,//左右分开消失
}

/**
 * @author wxl
 * 材质管理器
 */

export default class ShaderManager {

    static shaderName: string = null;

    /**
     * 
     * @param sprite 精灵
     * @param shader shader类型
     */
    static useShader(sprite: cc.Sprite, shader: ShaderType): ShaderMaterial {


        /** 着色器不支持画布 */
        if (cc.game.renderType === cc.game.RENDER_TYPE_CANVAS) {
            console.warn('Shader not surpport for canvas');
            return;
        }
        /** 设灰与精灵不存在 */
        if (!sprite || !sprite.spriteFrame || sprite.getState() === shader) {
            return;
        }

        if (shader > ShaderType.Gray) {
            /**  获取自定义shader*/
            let name = ShaderType[shader];
            let lab = ShaderLab[name];
            this.shaderName = name;
            /** shader不存在 */
            if (!lab) {
                console.warn('Shader not defined', name);
                return;
            }
            cc.dynamicAtlasManager.enabled = false;
            /** 获取当前shader相应的材质且设置参数 */
            let material = new ShaderMaterial(name, lab.vert, lab.frag, lab.defines || []);
            let texture = sprite.spriteFrame.getTexture();
            material.setTexture(texture);
            material.updateHash();
            // 切换到当前材质
            let sp = sprite as any;
            sp._material = material;
            sp._renderData._material = material;
            sp._state = shader;
            return material;
        }
        else {
            sprite.setState(shader);
        }
    }
}
