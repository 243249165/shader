import ShaderComponent from "./shader/ShaderComponent";
import ShaderManager from "./shader/ShaderManager";
import phantom from "./role/phantom";


const { ccclass, property } = cc._decorator;

@ccclass
export default class text extends cc.Component {

    /** 精灵节点 */
    @property(cc.Node)
    private spriteNode: cc.Node = null;
    private imageNode = null;
    private timeCount = 0;
    // onBtnCreat() {
    //     let node = new cc.Node();
    //     let sprite = node.addComponent(cc.Sprite);
    //     node.parent = this.node;
    //     node.name = 'image';
    //     cc.loader.load({ uuid: 'a62ac7a1-dbec-49e5-92cb-a09c84027f96' }, (err, spriteFrame) => {
    //         sprite.spriteFrame = spriteFrame;
    //         this.imageNode = sprite.node;
    //     });
    // }

    onBtnSet() {

        this.imageNode = this.node.getChildByName("roomMin");
        let shaderHelper = this.imageNode.getComponent(ShaderComponent);
        if (!shaderHelper) {
            shaderHelper = this.imageNode.addComponent(ShaderComponent);
        }
        if (this.timeCount >= 21) {
            this.timeCount = 0;
        } else {
            this.timeCount++
        }
        shaderHelper.shader = this.timeCount;
        console.log(this.timeCount);
        this.node.getChildByName("roomMin").getChildByName("text").getComponent(cc.Label).string = ShaderManager.shaderName;

    }

    onBtnGo() {
        this.spriteNode.stopAllActions();
        this.spriteNode.setPosition(0, 0);
        this.spriteNode.parent.getComponent(phantom).initSprite();
        this.spriteNode.runAction(cc.moveTo(5, 500, 0))
        // this.spriteNode.runAction(cc.repeatForever(cc.sequence(cc.moveTo(5, 1000, 0), cc.callFunc(() => {
        //     this.spriteNode.scaleX = -0.5;
        //     this.spriteNode.scaleY = 0.5;
        // }), cc.moveTo(5, 0, 0), cc.callFunc(() => {
        //     this.spriteNode.scaleX = 0.5;
        //     this.spriteNode.scaleY = 0.5;
        // }))));
    }

}
