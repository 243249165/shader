"use strict";
cc._RF.push(module, '70d0bHxjchOgLl9oySm1PPr', 'ShaderMaterial');
// shader/ShaderMaterial.ts

Object.defineProperty(exports, "__esModule", { value: true });
var renderEngine = cc.renderer.renderEngine;
var Material = renderEngine.Material;
/**
 * @author wxl
 * 自定义材质类
 */
var ShaderMaterial = /** @class */ (function (_super) {
    __extends(ShaderMaterial, _super);
    /** 创建材质 */
    function ShaderMaterial(name, vert, frag, defines) {
        var _this = _super.call(this, false) || this;
        /** 材质属性 */
        _this._texture = null;
        _this._color = null;
        _this._pos = null;
        _this._size = null;
        _this._time = null;
        _this._num = null;
        _this._effect = null;
        _this.effect = null;
        _this._mainTech = null;
        // 渲染对象
        var renderer = cc.renderer;
        var lib = renderer._forward._programLib;
        // 设置自定义参数
        !lib._templates[name] && lib.define(name, vert, frag, defines);
        _this._init(name);
        return _this;
    }
    ShaderMaterial.prototype._init = function (name) {
        var renderer = renderEngine.renderer;
        var gfx = renderEngine.gfx;
        var pass = new renderer.Pass(name);
        pass.setDepth(false, false);
        pass.setCullMode(gfx.CULL_NONE);
        // 设置混合模式
        pass.setBlend(gfx.BLEND_FUNC_ADD, gfx.BLEND_SRC_ALPHA, gfx.BLEND_ONE_MINUS_SRC_ALPHA, gfx.BLEND_FUNC_ADD, gfx.BLEND_SRC_ALPHA, gfx.BLEND_ONE_MINUS_SRC_ALPHA);
        // 设置材质属性
        var mainTech = new renderer.Technique(['transparent'], // 固定transparent，
        [
            { name: 'texture', type: renderer.PARAM_TEXTURE_2D },
            { name: 'color', type: renderer.PARAM_COLOR4 },
            { name: 'pos', type: renderer.PARAM_FLOAT3 },
            { name: 'size', type: renderer.PARAM_FLOAT2 },
            { name: 'time', type: renderer.PARAM_FLOAT },
            { name: 'num', type: renderer.PARAM_FLOAT }
        ], [pass]);
        this._texture = null;
        this._color = { r: 1.0, g: 1.0, b: 1.0, a: 1.0 };
        this._pos = { x: 0.0, y: 0.0, z: 0.0 };
        this._size = { x: 0.0, y: 0.0 };
        this._time = 0.0;
        this._num = 0.0;
        /** shader */
        this._effect = this.effect = new renderer.Effect([mainTech], {
            'color': this._color,
            'pos': this._pos,
            'size': this._size,
            'time': this._time,
            'num': this._num
        }, []);
        this._mainTech = mainTech;
    };
    /** 属性封装并设置材质属性 */
    ShaderMaterial.prototype.setTexture = function (texture) {
        this._texture = texture;
        this._texture.update({ flipY: false, mipmap: false });
        this._effect.setProperty('texture', texture.getImpl());
        this._texIds['texture'] = texture.getId();
    };
    ShaderMaterial.prototype.setColor = function (r, g, b, a) {
        this._color.r = r;
        this._color.g = g;
        this._color.b = b;
        this._color.a = a;
        this._effect.setProperty('color', this._color);
    };
    ShaderMaterial.prototype.setPos = function (x, y, z) {
        this._pos.x = x;
        this._pos.y = y;
        this._pos.z = z;
        this._effect.setProperty('pos', this._pos);
    };
    ShaderMaterial.prototype.setSize = function (x, y) {
        this._size.x = x;
        this._size.y = y;
        this._effect.setProperty('size', this._size);
    };
    ShaderMaterial.prototype.setTime = function (time) {
        this._time = time;
        this._effect.setProperty('time', this._time);
    };
    ShaderMaterial.prototype.setNum = function (num) {
        this._num = num;
        this._effect.setProperty('num', this._num);
    };
    return ShaderMaterial;
}(Material));
exports.default = ShaderMaterial;

cc._RF.pop();